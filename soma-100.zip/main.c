#include <stdio.h> //função para a entrada e saída de dados

int main () //função de determina exatamente o que será executado

{
    int x,y;     //regras das variáveis: não inicia com número, n tem acento, n tem caracter especial, tem tem separação de sílaba
                  // pode ter underline e faz diferença maiusculo e minusculo
                     //é um tipo de dado que manipula números inteiros
    int soma;
    
    x=100; //atribuição
    printf("O número x=%d\n", x); // expresso na tela
    printf("Escolha um número para somar com x\n");
    scanf("%d", &y); // digitado pelo usuario , %d tipo de dado que será lido, &y onde sera armazenado
    printf("O número y=%d\n", y);
    soma=y+x;
    printf("A soma de %d+%d=%d", x, y, soma);
    
}


